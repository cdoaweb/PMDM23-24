package com.pmdm.api_movies

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class SearchResponse(
    @SerializedName("Search")
    @Expose
    val Search: List<Movie>
)
