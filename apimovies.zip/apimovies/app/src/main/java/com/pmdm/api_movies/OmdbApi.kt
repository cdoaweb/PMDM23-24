package com.pmdm.api_movies

import retrofit2.Call
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

interface OmdbApi {
    @GET("/")
    suspend fun searchMovies(@Query("s") searchTerm: String, @Query("i") i: String, @Query("apikey") apikey: String): Response<SearchResponse>
}
