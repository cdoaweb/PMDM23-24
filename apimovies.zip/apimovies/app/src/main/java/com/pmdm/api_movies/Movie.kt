package com.pmdm.api_movies


data class Movie(
    val Title: String,
    val Year: String,
    val Poster: String
)
