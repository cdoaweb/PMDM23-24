package com.pmdm.api_movies

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val mainActivity = this

        val retrofitInstance = RetrofitClient.getInstance()
        lifecycleScope.launch {
            val response = RetrofitClient.getService(retrofitInstance).searchMovies("Batman", "tt3896198", "1b28bd57")
            val movies = response.body()?.Search ?: emptyList()
            Toast.makeText(mainActivity, movies.get(0).Title, Toast.LENGTH_LONG).show()
            val recyclerView = findViewById<RecyclerView>(R.id.recycler)
            recyclerView.layoutManager = LinearLayoutManager(mainActivity)
            recyclerView.adapter = MoviesAdapter(movies)
        }


    }
}