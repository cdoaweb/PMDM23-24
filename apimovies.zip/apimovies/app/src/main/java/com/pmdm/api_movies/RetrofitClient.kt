package com.pmdm.api_movies

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object RetrofitClient {
    fun getInstance(): Retrofit {
        return Retrofit.Builder()
            .baseUrl("https://www.omdbapi.com")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            //.create(OmdbApi::class.java)
    }

    fun getService(retrofit : Retrofit) : OmdbApi {
        return retrofit.create(OmdbApi::class.java)
    }
}
